﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;

namespace SignalR_Demo
{
    public class ChatHub : Hub
    {
        public void Send(string name,string message)
        {
            // Here calls the broadcast message to update all connected clients.
            Clients.All.broadcastMessage(name,message);
        }

        public void startedtyping(string name)
        {
            Clients.All.starttyping(name);
        }
        public void stoppedtyping(string name)
        {
            Clients.All.stoptyping(name);
        }
    }
}