﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SignalR_Demo
{
    public class Messages
    {
        public int messageid { get; set; }
        public string msgfrom{ get; set; }
        public string msgto { get; set; }
        public string message{ get; set; }
        public bool delivered{ get; set; }
        public bool isviewed{ get; set; }
    }
}