﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SignalR_Demo
{
    public class Users
    {
        public Guid userid { get; set; }
        public string email { get; set; }
        public string username{ get; set; }
        public string password{ get; set; }
        public bool isactive { get; set; }
        public bool isonline{ get; set; }
        public int code{ get; set; }

    }
}