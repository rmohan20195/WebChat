﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace SignalR_Demo
{
    public class DAL
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);

        public List<Users> GetFriends(Guid id)
        {
            SqlDataAdapter adp = new SqlDataAdapter("Friends_GetAll",conn);
            adp.SelectCommand.Parameters.AddWithValue("@id", id);
            adp.SelectCommand.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            adp.Fill(dt);

            List<Users> users = new List<Users>();
            users = Help.DataTableToList<Users>(dt);
            return users; 
        }

        public int User_Create(Users u)
        {
            SqlCommand cmd = new SqlCommand("User_Create",conn);
            cmd.Parameters.AddWithValue("@email",u.email);
            cmd.Parameters.AddWithValue("@password", u.password);
            cmd.Parameters.AddWithValue("@username", u.username);
            cmd.CommandType = CommandType.StoredProcedure;

            if(conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            int result = cmd.ExecuteNonQuery();
            conn.Close();
            return result;
        }
    }
}